/**
 * OpenFront Population Display Chrome Extension
 * 
 * This extension enhances OpenFront.io gaming experience with:
 * 1. Real-time population statistics display
 * 2. Lofi music player for background ambience
 */

// ===== CONFIGURATION =====
const CONFIG = {
  updateInterval: 1000,  // How often to update population display (ms)
  navigationCheckInterval: 500,  // How often to check for URL changes (ms)
  lofiYoutubeEmbedUrl: 'https://www.youtube.com/embed/jfKfPfyJRdk?si=OmegLvyuJMmQg_EK&autoplay=1&mute=0',
  lofiTexts: {
    playing: "Stop, I need to focus 😶",
    stopped: "Brings the Chill Vibes 🎶"
  }
};

// ===== DOM ELEMENTS =====
// Create cached references to DOM elements
const elements = {
  display: null,
  lofiContainer: null,
  // These will be populated after elements are created
  currentElement: null,
  totalElement: null,
  percentElement: null,
  lofiText: null
};

// ===== STATE MANAGEMENT =====
const state = {
  isLofiPlaying: false,
  lastPath: window.location.pathname,
  intervals: []
};

// ===== POPULATION DISPLAY MODULE =====
const populationDisplay = {
  /**
   * Extracts population values from the DOM
   * @returns {Object} Object containing current and total population values
   */
  extractPopulation() {
    try {
      // Find the container with population info
      const container = document.querySelector('.bg-black\\/30.text-white');
      if (!container) return { current: '0', total: '0' };

      // Find the population value
      const popElement = Array.from(container.querySelectorAll('div')).find(
        div => div.textContent.includes('Pop:')
      );
      if (!popElement) return { current: '0', total: '0' };

      // Extract both current and total population values
      const text = popElement.querySelector('span[translate="no"]')?.textContent || '';
      const values = text.match(/(\d+\.?\d*K?)\s*\/\s*(\d+\.?\d*K?)/);
      return values ? { current: values[1], total: values[2] } : { current: '0', total: '0' };
    } catch (error) {
      console.error('Error extracting population:', error);
      return { current: '0', total: '0' };
    }
  },

  /**
   * Parses a population string (e.g. "5.2K") to a number
   * @param {string} popString - Population string to parse
   * @returns {number} Parsed population value
   */
  parsePopulationValue(popString) {
    if (!popString || popString === '0') return 0;
    const numStr = popString.replace('K', '');
    return parseFloat(numStr) || 0;
  },

  /**
   * Updates the population display with current values
   */
  updateDisplay() {
    // Extract population values
    const { current, total } = this.extractPopulation();
    
    // Don't display the population stats before the game starts (when pop is 0 or not found)
    const currentNum = this.parsePopulationValue(current);
    if (currentNum === 0) {
      elements.display.style.display = 'none';
      return;
    } else {
      elements.display.style.display = 'block';
    }
    
    // Update the population stats
    if (elements.currentElement && elements.totalElement) {
      elements.currentElement.textContent = current;
      elements.totalElement.textContent = total;
      
      // Calculate and update percentage
      if (elements.percentElement) {
        const totalNum = this.parsePopulationValue(total);
        const percentage = totalNum > 0 ? Math.round((currentNum / totalNum) * 100) : 0;
        elements.percentElement.textContent = `${percentage}%`;
      }
    }
  },

  /**
   * Creates and injects the population display element
   */
  createDisplayElement() {
    elements.display = document.createElement('div');
    elements.display.className = 'openfront-population-display';
    elements.display.innerHTML = `
      <div class="openfront-stats">
        Population: <span class="value">0</span> / <span class="total-value">0</span> (<span class="percent-value">0%</span>)
      </div>
    `;
    document.body.appendChild(elements.display);
    
    // Cache element references for better performance
    elements.currentElement = elements.display.querySelector('.value');
    elements.totalElement = elements.display.querySelector('.total-value');
    elements.percentElement = elements.display.querySelector('.percent-value');
  },

  /**
   * Initializes the population display module
   */
  init() {
    this.createDisplayElement();
    this.updateDisplay(); // Initial update
    
    // Set up update interval
    const updateInterval = setInterval(() => this.updateDisplay(), CONFIG.updateInterval);
    state.intervals.push(updateInterval);
  }
};

// ===== LOFI PLAYER MODULE =====
const lofiPlayer = {
  /**
   * Toggles the lofi hip hop music
   */
  toggleMusic() {
    if (state.isLofiPlaying) {
      this.stopMusic();
    } else {
      this.startMusic();
    }
  },
  
  /**
   * Starts the lofi music
   */
  startMusic() {
    // Create and add the YouTube iframe
    const iframe = document.createElement('iframe');
    iframe.id = 'lofi-iframe';
    iframe.width = '0';  // Hidden but still playing audio
    iframe.height = '0';
    iframe.style.position = 'absolute';
    iframe.style.bottom = '0';
    iframe.style.right = '0';
    iframe.style.opacity = '0.01';  // Nearly invisible but still functional
    iframe.style.pointerEvents = 'none';  // Prevent interaction
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.src = CONFIG.lofiYoutubeEmbedUrl;
    iframe.title = 'Lofi Hip Hop Radio';
    iframe.frameBorder = '0';
    
    document.body.appendChild(iframe);
    
    state.isLofiPlaying = true;
    
    // Update button text
    if (elements.lofiText) {
      elements.lofiText.innerHTML = `<span class="typing-text">${CONFIG.lofiTexts.playing}</span>`;
    }
  },
  
  /**
   * Stops the lofi music
   */
  stopMusic() {
    // Stop the music by removing the iframe
    const existingIframe = document.getElementById('lofi-iframe');
    if (existingIframe) {
      existingIframe.remove();
    }
    
    state.isLofiPlaying = false;
    
    // Update button text
    if (elements.lofiText) {
      elements.lofiText.innerHTML = `<span class="typing-text">${CONFIG.lofiTexts.stopped}</span>`;
    }
  },

  /**
   * Creates and injects the lofi player button
   */
  createLofiElement() {
    elements.lofiContainer = document.createElement('div');
    elements.lofiContainer.className = 'openfront-lofi-container';
    elements.lofiContainer.innerHTML = `
      <img class="openfront-character-image" src="${chrome.runtime.getURL('img/characters/lofigirl.webp')}">
      <span class="openfront-audio-title"><span class="typing-text">${CONFIG.lofiTexts.stopped}</span></span>
    `;
    document.body.appendChild(elements.lofiContainer);
    
    // Cache element reference
    elements.lofiText = elements.lofiContainer.querySelector('.openfront-audio-title');
    
    // Add click event listener
    elements.lofiContainer.addEventListener('click', () => this.toggleMusic());
  },

  /**
   * Initializes the lofi player module
   */
  init() {
    this.createLofiElement();
    
    // Ensure the lofi button is added to the page after a short delay
    // This helps with single-page apps that might remove our elements
    setTimeout(() => {
      if (!document.body.contains(elements.lofiContainer)) {
        document.body.appendChild(elements.lofiContainer);
      }
    }, 2000);
  }
};

// ===== PAGE NAVIGATION HANDLER =====
const navigationHandler = {
  /**
   * Checks for URL changes and updates UI accordingly
   */
  checkForNavigation() {
    const currentPath = window.location.pathname;
    if (currentPath !== state.lastPath) {
      state.lastPath = currentPath;
      
      // Update population display after navigation
      populationDisplay.updateDisplay();
      
      // Ensure lofi button is still in the DOM after page navigation
      if (!document.body.contains(elements.lofiContainer)) {
        document.body.appendChild(elements.lofiContainer);
      }
    }
  },
  
  /**
   * Initializes the navigation handler
   */
  init() {
    const navInterval = setInterval(() => this.checkForNavigation(), CONFIG.navigationCheckInterval);
    state.intervals.push(navInterval);
  }
};

// ===== CLEANUP HANDLER =====
const cleanup = {
  /**
   * Performs cleanup when the page is unloaded
   */
  onUnload() {
    // Clear all intervals
    state.intervals.forEach(interval => clearInterval(interval));
    
    // Remove DOM elements
    if (elements.display) elements.display.remove();
    if (elements.lofiContainer) elements.lofiContainer.remove();
    
    // Remove lofi iframe if it exists
    const lofiIframe = document.getElementById('lofi-iframe');
    if (lofiIframe) lofiIframe.remove();
  },
  
  /**
   * Initializes the cleanup handler
   */
  init() {
    window.addEventListener('unload', () => this.onUnload());
  }
};

// ===== INITIALIZE EXTENSION =====
function initExtension() {
  populationDisplay.init();
  lofiPlayer.init();
  navigationHandler.init();
  cleanup.init();
}

// Start the extension
initExtension();
